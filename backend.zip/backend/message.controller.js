import cloudinary from "../cloudinary.js";
import { getReceiverSocketId } from "../../socket.js";
import { io } from "../../socket.js"
import Message from "../../models/message.model.js";
import UserModel from "../../models/Users.js";
import HouseOwerModel from "../../models/HouseOwners.js";
import { upload } from '../multerConfig.js';

// import { emitToUser } from "../../helpers/socketHelpers.js";
export const getUsersForSidebar = async (req, res) => {
    try {
        const { loggedInUserId } = req.params;
        const filteredUsers = await UserModel.find({ _id: { $ne: loggedInUserId } }).select('-password');
        const filteredOwners = await HouseOwerModel.find({ _id: { $ne: loggedInUserId } }).select('-password');
        if (!filteredUsers || !filteredOwners) {
            return res.status(404).json({ message: "No users found" });
        }
        res.status(200).json({ filteredUsers, filteredOwners });
    } catch (error) {
        console.log("Error in getUsersForSidebar: ", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
}


export const getMessages = async (req, res) => {
    try {
        const { id: userToChatId } = req.params;
        const { myId } = req.query;

        if (!myId) {
            return res.status(400).json({ error: "myId is required" });
        }

        const messages = await Message.find({
            $or: [
                { senderId: myId, receiverId: userToChatId },
                { senderId: userToChatId, receiverId: myId }
            ]
        }).sort({ createdAt: 1 });

        res.status(200).json(messages);
    } catch (error) {
        console.log("Error in getMessages:", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
};



























// export const sendMessage = [
//     upload.fields([
//         { name: "image", maxCount: 1 },
//         { name: "video", maxCount: 1 },
//     ]),
//     async (req, res) => {
//         try {
//             const { id: receiverId } = req.params;
//             // Prefer authenticated user id (req.user), fallback to body
//             const senderId = req.user?._id?.toString() || req.body.senderId;

//             if (!senderId || !receiverId)
//                 return res.status(400).json({ error: "senderId and receiverId required" });

//             const { text = "" } = req.body;

//             let imageUrl = null;
//             let videoUrl = null;

//             if (req.files?.image?.[0]) {
//                 imageUrl = await new Promise((resolve, reject) => {
//                     const stream = cloudinary.uploader.upload_stream({ resource_type: "image" }, (err, result) =>
//                         err ? reject(err) : resolve(result.secure_url)
//                     );
//                     stream.end(req.files.image[0].buffer);
//                 });
//             }

//             if (req.files?.video?.[0]) {
//                 videoUrl = await new Promise((resolve, reject) => {
//                     const stream = cloudinary.uploader.upload_stream({ resource_type: "video" }, (err, result) =>
//                         err ? reject(err) : resolve(result.secure_url)
//                     );
//                     stream.end(req.files.video[0].buffer);
//                 });
//             }

//             const newMessage = new Message({
//                 senderId,
//                 receiverId,
//                 text,
//                 image: imageUrl,
//                 video: videoUrl,
//             });

//             await newMessage.save();

//             // Emit to receiver(s)
//             const receiverSockets = getReceiverSocketId(receiverId);
//             receiverSockets.forEach((sockId) => io.to(sockId).emit("newMessage", newMessage));

//             // Echo to sender's other sockets (so the sender's other tabs/devices also receive it)
//             const senderSockets = getReceiverSocketId(senderId);
//             senderSockets.forEach((sockId) => io.to(sockId).emit("newMessage", newMessage));

//             return res.status(201).json(newMessage);
//         } catch (error) {
//             console.error("Error in sendMessage:", error);
//             return res.status(500).json({ error: "Internal Server Error" });
//         }
//     },
// ];
















export const sendMessage = [
    upload.fields([
        { name: "image", maxCount: 1 },
        { name: "video", maxCount: 1 },
    ]),
    async (req, res) => {
        try {
            const { id: receiverId } = req.params;
            const senderId = req.user?._id?.toString() || req.body.senderId;

            if (!senderId || !receiverId) {
                return res.status(400).json({ error: "senderId and receiverId required" });
            }

            const { text = "" } = req.body;

            let imageUrl = null;
            let videoUrl = null;

            if (req.files?.image?.[0]?.buffer) {
                imageUrl = await new Promise((resolve, reject) => {
                    cloudinary.uploader.upload_stream(
                        { resource_type: "image" },
                        (err, result) => err ? reject(err) : resolve(result.secure_url)
                    ).end(req.files.image[0].buffer);
                });
            }

            if (req.files?.video?.[0]?.buffer) {
                videoUrl = await new Promise((resolve, reject) => {
                    cloudinary.uploader.upload_stream(
                        { resource_type: "video" },
                        (err, result) => err ? reject(err) : resolve(result.secure_url)
                    ).end(req.files.video[0].buffer);
                });
            }

            const newMessage = new Message({
                senderId,
                receiverId,
                text,
                image: imageUrl,
                video: videoUrl,
                readistrue: false
            });

            await newMessage.save();

            const receiverSockets = getReceiverSocketId(receiverId) || [];
            receiverSockets.forEach(id => io.to(id).emit("newMessage", newMessage));

            const senderSockets = getReceiverSocketId(senderId) || [];
            senderSockets.forEach(id => io.to(id).emit("newMessage", newMessage));

            res.status(201).json(newMessage);
        } catch (error) {
            console.error("SEND MESSAGE ERROR:", error);
            res.status(500).json({ error: error.message });
        }
    }
];








// markMessagesAsRead
// markMessagesAsRead
// export const markMessagesAsRead = async (req, res) => {
//     try {
//         const { chatUserId } = req.params; // the sender of messages
//         const readerId =  req.body.readerId;

//         if (!chatUserId || !readerId) {
//             return res.status(400).json({ error: "chatUserId and readerId required" });
//         }

//         // Update all messages sent TO reader FROM chatUser
//         const result = await Message.updateMany(
//             {
//                 senderId: chatUserId,
//                 receiverId: readerId,
//                 readistrue: false
//             },
//             { $set: { readistrue: true } }
//         );

//         console.log("Messages marked as read:", result.modifiedCount);

//         return res.status(200).json({
//             success: true,
//             updatedCount: result.modifiedCount
//         });
//     } catch (error) {
//         console.error("markMessagesAsRead error:", error);
//         return res.status(500).json({ error: "Internal Server Error" });
//     }
// };












export const markMessagesAsRead = async (req, res) => {
    try {
        const { chatUserId } = req.params;   // sender
        const { readerId } = req.body;       // viewer

        if (!chatUserId || !readerId) {
            return res.status(400).json({ error: "chatUserId and readerId required" });
        }

        // 1️⃣ Update DB
        const result = await Message.updateMany(
            {
                senderId: chatUserId,
                receiverId: readerId,
                readistrue: false
            },
            { $set: { readistrue: true } }
        );

        // 2️⃣ Notify sender in real time (blue tick)
        const senderSockets = getReceiverSocketId(chatUserId) || [];
        senderSockets.forEach(id =>
            io.to(id).emit("messagesRead", {
                byUserId: readerId,
                chatUserId
            })
        );

        return res.status(200).json({
            success: true,
            updatedCount: result.modifiedCount
        });
    } catch (error) {
        console.error("MARK MESSAGES READ ERROR:", error);
        res.status(500).json({ error: error.message });
    }
};




// Get latest messages grouped by conversation for a user
export const getMessagesByUser = async (req, res) => {
    try {
        const { userId } = req.params; // the logged-in user

        if (!userId) {
            return res.status(400).json({ error: "userId is required" });
        }

        // 1️⃣ Fetch all messages involving this user
        const messages = await Message.find({
            $or: [{ senderId: userId }, { receiverId: userId }]
        }).sort({ createdAt: -1 }); // newest first

        if (!messages.length) {
            return res.status(200).json({ conversations: [] });
        }

        // 2️⃣ Group by other participant
        const conversationsMap = {};

        messages.forEach(msg => {
            const otherUserId =
                String(msg.senderId) === String(userId)
                    ? String(msg.receiverId)
                    : String(msg.senderId);

            // Only keep the latest message per conversation
            if (!conversationsMap[otherUserId]) {
                conversationsMap[otherUserId] = {
                    userId: otherUserId,
                    lastMessage: msg.text || msg.image || msg.video || "",
                    timestamp: msg.createdAt,
                    read: msg.readistrue
                };
            }
        });

        // 3️⃣ Convert map to array & sort by latest timestamp
        const conversations = Object.values(conversationsMap).sort(
            (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
        );

        res.status(200).json({ conversations });
    } catch (error) {
        console.error("Error in getMessagesByUser:", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
